Файл скачать с сайта https://softdroids.com/
